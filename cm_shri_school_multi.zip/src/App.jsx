import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import Faculty from './pages/Faculty';
import Gallery from './pages/Gallery';
import Rules from './pages/Rules';
import Cocurricular from './pages/Cocurricular';
import Contact from './pages/Contact';

export default function App(){
  return (
    <div>
      <header className="bg-white shadow fixed top-0 left-0 right-0 z-50">
        <div className="container flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <img src="%PUBLIC_URL%/logo.jpg" alt="logo" className="w-14 h-14 object-cover rounded" />
            <div>
              <div className="font-bold text-lg">CM Shri School</div>
              <div className="text-sm text-gray-500">ignite your minds</div>
            </div>
          </div>
          <nav className="space-x-4">
            <Link to="/" className="text-sm font-medium">Home</Link>
            <Link to="/about" className="text-sm font-medium">About</Link>
            <Link to="/faculty" className="text-sm font-medium">Faculty</Link>
            <Link to="/gallery" className="text-sm font-medium">Gallery</Link>
            <Link to="/rules" className="text-sm font-medium">Rules</Link>
            <Link to="/co-curricular" className="text-sm font-medium">Co-curricular</Link>
            <Link to="/contact" className="text-sm font-medium">Contact</Link>
          </nav>
        </div>
      </header>
      <main className="pt-28">
        <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/about' element={<About/>} />
          <Route path='/faculty' element={<Faculty/>} />
          <Route path='/gallery' element={<Gallery/>} />
          <Route path='/rules' element={<Rules/>} />
          <Route path='/co-curricular' element={<Cocurricular/>} />
          <Route path='/contact' element={<Contact/>} />
        </Routes>
      </main>
      <footer className="bg-white border-t mt-8">
        <div className="container py-6 text-sm text-gray-600 flex justify-between">
          <div>© {new Date().getFullYear()} CM Shri School</div>
          <div>Sector 5, Dwarka • +91-9876543210 • cmshridwk5@gmail.com</div>
        </div>
      </footer>
    </div>
  );
}
