import React from 'react';
const Gallery = ()=>(
  <div className="container">
    <h1 className="text-2xl font-bold">Gallery</h1>
    <div className="grid md:grid-cols-4 gap-3 mt-4">
      {Array.from({length:8}).map((_,i)=>(
        <img key={i} src={`https://picsum.photos/seed/g${i}/800/600`} alt={`g${i}`} className="w-full h-40 object-cover rounded"/>
      ))}
    </div>
  </div>
);
export default Gallery;
