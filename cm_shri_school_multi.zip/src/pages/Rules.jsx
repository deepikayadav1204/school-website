import React from 'react';
const Rules = ()=>(
  <div className="container">
    <h1 className="text-2xl font-bold">School Rules</h1>
    <ol className="mt-4 text-gray-600 list-decimal list-inside">
      <li>Attend school regularly and be punctual.</li>
      <li>Wear the proper school uniform and ID card.</li>
      <li>Respect teachers, staff, and fellow students.</li>
      <li>Maintain cleanliness and keep the campus litter-free.</li>
      <li>Use mobile phones only with teacher permission.</li>
      <li>Follow safety rules in labs and playgrounds.</li>
      <li>Complete homework and assignments on time.</li>
      <li>Bullying or discrimination will not be tolerated.</li>
      <li>Parents should inform the school of absences.</li>
      <li>Students must follow transport rules during commutes.</li>
    </ol>
  </div>
);
export default Rules;
