import React from 'react';
const Faculty = ()=>(
  <div className="container">
    <h1 className="text-2xl font-bold">Faculty</h1>
    <div className="grid md:grid-cols-3 gap-4 mt-4">
      <div className="card p-4">
        <img src="https://picsum.photos/seed/t1/600/400" alt="p1" className="w-full h-48 object-cover rounded"/>
        <h3 className="mt-3 font-semibold">Dr. A. Sharma</h3>
        <div className="text-gray-600">Principal</div>
      </div>
      <div className="card p-4">
        <img src="https://picsum.photos/seed/t2/600/400" alt="p2" className="w-full h-48 object-cover rounded"/>
        <h3 className="mt-3 font-semibold">Ms. R. Gupta</h3>
        <div className="text-gray-600">Vice Principal</div>
      </div>
      <div className="card p-4">
        <img src="https://picsum.photos/seed/t3/600/400" alt="p3" className="w-full h-48 object-cover rounded"/>
        <h3 className="mt-3 font-semibold">Mr. S. Verma</h3>
        <div className="text-gray-600">Academic Coordinator</div>
      </div>
    </div>
  </div>
);
export default Faculty;
