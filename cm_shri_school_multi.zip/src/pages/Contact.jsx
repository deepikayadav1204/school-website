import React from 'react';
const Contact = ()=>(
  <div className="container">
    <h1 className="text-2xl font-bold">Contact Us</h1>
    <div className="grid md:grid-cols-2 gap-6 mt-4">
      <div className="card p-4">
        <form onSubmit={(e)=>{ e.preventDefault(); alert('Demo: message sent'); e.target.reset(); }}>
          <div className="flex gap-2">
            <input required name="name" placeholder="Your name" className="flex-1 p-2 border rounded"/>
            <input required name="email" placeholder="Your email" className="flex-1 p-2 border rounded"/>
          </div>
          <textarea required name="message" placeholder="Message" className="w-full p-2 border rounded mt-3"></textarea>
          <button className="mt-3 px-4 py-2 bg-blue-600 text-white rounded">Send Message</button>
        </form>
      </div>
      <div className="card p-4">
        <h3 className="font-semibold">Address</h3>
        <p className="text-gray-600 mt-2">Sector 5, Dwarka, New Delhi</p>
        <p className="text-gray-600">Phone: +91-9876543210</p>
        <p className="text-gray-600">Email: cmshridwk5@gmail.com</p>
        <div className="mt-3">
          <iframe src="https://www.google.com/maps?q=Sector+5+Dwarka+New+Delhi&output=embed" width="100%" height="200" style={{border:0,borderRadius:8}} title="map"></iframe>
        </div>
      </div>
    </div>
  </div>
);
export default Contact;
