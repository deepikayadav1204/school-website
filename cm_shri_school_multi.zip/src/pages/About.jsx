import React from 'react';
const About = ()=>(
  <div className="container">
    <h1 className="text-2xl font-bold">About Us</h1>
    <p className="text-gray-600 mt-3">CM Shri School was established with the vision to empower students through a balanced education that combines academics with values. We follow a student-centered approach and provide modern facilities including well-stocked libraries, science and computer labs, and extensive sports grounds.</p>

    <div className="grid md:grid-cols-3 gap-4 mt-6">
      <div className="card p-4">
        <h3 className="font-semibold">Our Mission</h3>
        <p className="text-gray-600 mt-2">To ignite curiosity and foster lifelong learning among students while nurturing character and leadership.</p>
      </div>
      <div className="card p-4">
        <h3 className="font-semibold">Our Vision</h3>
        <p className="text-gray-600 mt-2">To be a leading educational institution recognized for academic excellence and holistic development.</p>
      </div>
      <div className="card p-4">
        <h3 className="font-semibold">Facilities</h3>
        <p className="text-gray-600 mt-2">Library, Science Labs, Computer Lab, Auditorium, Playgrounds, Transport Facility, Well-qualified staff.</p>
      </div>
    </div>
  </div>
);
export default About;
