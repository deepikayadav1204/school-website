import React from 'react';
import Slider from 'react-slick';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

const Home = () => {
  const settings = {
    dots: true,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 4000,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  return (
    <div className="container">
      <section className="mb-8">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h1 className="text-3xl font-bold">Welcome to CM Shri School</h1>
            <p className="text-gray-600 mt-2">A place where knowledge meets character. Nurturing young minds to be future-ready leaders.</p>
            <div className="mt-4 space-x-2">
              <a className="px-4 py-2 bg-blue-600 text-white rounded" href="/contact">Admission Enquiry</a>
            </div>

            <div className="mt-6">
              <h3 className="font-semibold">Principal's Message</h3>
              <div className="flex items-start gap-4 mt-3">
                <img src="%PUBLIC_URL%/logo.jpg" alt="principal" className="w-20 h-20 object-cover rounded" />
                <div>
                  <h4 className="font-semibold">Dr. A. Sharma</h4>
                  <p className="text-gray-600 mt-2">Welcome to CM Shri School. We are committed to excellent education and holistic development. Together we will ignite young minds.</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <Slider {...settings}>
              <div><img src="https://picsum.photos/seed/s1/1200/700" alt="slide1" className="w-full h-64 object-cover rounded"/></div>
              <div><img src="https://picsum.photos/seed/s2/1200/700" alt="slide2" className="w-full h-64 object-cover rounded"/></div>
              <div><img src="https://picsum.photos/seed/s3/1200/700" alt="slide3" className="w-full h-64 object-cover rounded"/></div>
            </Slider>

            <div className="mt-4 card p-4">
              <h4 className="font-semibold">Virtual Tour</h4>
              <div className="mt-2">
                <iframe width="100%" height="200" src="https://www.youtube.com/embed/ysz5S6PUM-U" title="Virtual tour" frameBorder="0" allowFullScreen></iframe>
              </div>
            </div>

            <div className="mt-4 card p-4">
              <h4 className="font-semibold">Newsletter</h4>
              <p className="text-gray-600 mt-2">Download our latest newsletter.</p>
              <a href="#" className="inline-block mt-2 px-3 py-2 bg-gray-800 text-white rounded">Download (Sample)</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
