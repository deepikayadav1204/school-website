import React from 'react';
const Cocurricular = ()=>(
  <div className="container">
    <h1 className="text-2xl font-bold">Co-curricular Activities</h1>
    <div className="grid md:grid-cols-3 gap-4 mt-4">
      <div className="card p-4">
        <h3 className="font-semibold">Sports</h3>
        <p className="text-gray-600 mt-2">Inter-house competitions, athletics, football, cricket, basketball, and yoga sessions.</p>
      </div>
      <div className="card p-4">
        <h3 className="font-semibold">Arts & Music</h3>
        <p className="text-gray-600 mt-2">Art club, music classes, dance workshops, and theatre activities to encourage creativity.</p>
      </div>
      <div className="card p-4">
        <h3 className="font-semibold">Clubs & Societies</h3>
        <p className="text-gray-600 mt-2">Science club, Eco club, Debate society, Coding club, and Community service initiatives.</p>
      </div>
    </div>
  </div>
);
export default Cocurricular;
